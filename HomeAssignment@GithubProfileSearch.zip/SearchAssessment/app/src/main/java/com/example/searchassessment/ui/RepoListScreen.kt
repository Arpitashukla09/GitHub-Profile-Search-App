package com.example.searchassessment.ui

import android.webkit.WebView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import data.GHRepo

@Composable
fun RepoListScreen(repos: List<GHRepo>) {
    // State for WebView URL
    var selectedRepoURL by remember { mutableStateOf<String?>(null) }

    if (selectedRepoURL == null) {
        // Show the list of repositories
        LazyColumn {
            items(repos) { repo ->
                RepoItem(repo) { clickedRepoURL ->
                    selectedRepoURL = clickedRepoURL
                }
            }
        }
    } else {
        // Show WebView for the selected repository
        WebViewScreen(repoURL = selectedRepoURL) {
            selectedRepoURL = null // Go back to the list when back is pressed
        }
    }
}

@Composable
fun RepoItem(repo: GHRepo, onClick: (String) -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .clickable { onClick(repo.repoURL) }, // Handle click

    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = repo.name, style = MaterialTheme.typography.bodyMedium)
            Text(text = repo.repoURL, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun WebViewScreen(repoURL: String?, onBackPressed: () -> Unit) {
    val context = LocalContext.current

    // Handle back button press
    BackHandler(enabled = true) {
        onBackPressed()
    }

    AndroidView(factory = {
        WebView(context).apply {
            settings.javaScriptEnabled = true
            loadUrl(repoURL ?: "")
        }
    })
}
